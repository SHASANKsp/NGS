#!/usr/bin/env nextflow
 
/*
vim: syntax=groovy
-*- mode: groovy;-*-
 *
 * Copyright (c) 2013-2016, Centre for Genomic Regulation (CRG).
 * Copyright (c) 2013-2016, Paolo Di Tommaso and the respective authors.
 *
 *   This file is part of 'Nextflow'.
 *
 *   Nextflow is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   Nextflow is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with Nextflow.  If not, see <http://www.gnu.org/licenses/>.
 */ 
 
/*  
 * Basic example showing how read and write a file content 
 */ 
 
my_file = file("$baseDir/data/sample.fa")
print my_file.text

/* 
 * In order to create a file simply assign a value to the 
 * `text` property  
 */ 
 
new_file = file('my_file')
new_file.text = 'Hello world!\n'

/* 
 * The left shift operator append a string a file
 */

new_file << 'Append a new line\n'